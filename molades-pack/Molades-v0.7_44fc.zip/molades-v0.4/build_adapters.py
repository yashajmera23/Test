#!/usr/bin/env python3
"""
Generate all adapter formats from the canonical skills/*/SKILL.md.

Single source of truth: skills/. Never hand-edit an adapter — edit the skill
and re-run this. v0.3 shipped hand-maintained adapters and they drifted from
the skills they mirrored within one release.

Usage:  python3 build_adapters.py
"""

import os
import re
import pathlib

ROOT = pathlib.Path(__file__).parent
SKILLS = ROOT / "skills"
ADAPTERS = ROOT / "adapters"

ORDER = [
    "molades-start",
    "molades-scope",
    "molades-landscape",
    "molades-research",
    "molades-synthesise",
    "molades-define",
    "molades-language",
    "molades-build",
    "molades-stress",
    "molades-craft",
    "molades-challenge",
    "molades-case",
]


def parse(path):
    """Split a SKILL.md into (name, description, body)."""
    text = path.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    if not m:
        raise ValueError(f"{path} has no frontmatter")
    fm, body = m.group(1), m.group(2).lstrip("\n")
    name = re.search(r"^name:\s*(.+)$", fm, re.M).group(1).strip()
    desc = re.search(r"^description:\s*(.+?)(?=\n\w+:|\Z)", fm, re.M | re.S)
    desc = " ".join(desc.group(1).split())
    return name, desc, body


def load_all():
    out = []
    for slug in ORDER:
        p = SKILLS / slug / "SKILL.md"
        if not p.exists():
            raise SystemExit(f"missing: {p}")
        out.append((slug,) + parse(p))
    return out


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def build_cursor(skills):
    """Cursor .mdc — frontmatter with alwaysApply: false, then the body."""
    made = []
    for slug, name, desc, body in skills:
        content = (
            "---\n"
            f"description: {desc}\n"
            "alwaysApply: false\n"
            "---\n\n"
            f"{body}"
        )
        made.append(write(ADAPTERS / "cursor" / f"{slug}.mdc", content))
    return made


def build_paste(skills):
    """Paste blocks for tools with no filesystem. Prepends a standing preamble."""
    preamble = (
        "You are running one procedure from the Molades build system for design "
        "students. Follow it exactly. Ignore any earlier instructions in this "
        "conversation that conflict with it.\n\n"
        "HOW YOU TALK, and this outranks everything below it: you are a teacher "
        "sitting next to someone, talking. Not a document. Readability comes from "
        "length and structure, not from vocabulary.\n\n"
        "Most replies under 120 words. One idea per paragraph. No headers, bullet "
        "lists or tables in conversation. One question, at the end, on its own "
        "line. No preamble, no recap.\n\n"
        "Use the course's words freely - jobs to be done, affinity clusters, AARRR "
        "stage, problem statement, scope card, hypothesis, persona, user flow, "
        "information architecture, wireframe, heuristic. Gloss each in half a line "
        "the first time it comes up, then just use it.\n\n"
        "Do not use the system's internal terms, which I have never heard: object "
        "model, root layer, artefact, traceability, provisional, confidence tag, "
        "intake, gate, the spine, the probe. Never name the method - I need to know "
        "my button says the wrong thing, not that you ran a heuristic walk.\n\n"
        "Use my words and my participants' names. When in doubt, cut the reply in "
        "half and send that instead.\n\n"
        "This tool has no filesystem, so two things change and nothing else does: "
        "you hand back files as complete blocks for me to save, and you hand back "
        "log entries as blocks for me to paste into LOG.md. Everything you would "
        "otherwise write to disk, you give to me instead. Never tell me a step "
        "cannot be done here - tell me which part I am doing by hand.\n\n"
        "---\n\n"
    )
    made = []
    for slug, name, desc, body in skills:
        made.append(write(ADAPTERS / "paste" / f"{slug}-PASTE.md", preamble + body))
    return made


def build_agents(skills):
    """One AGENTS.md holding every procedure."""
    parts = [
        "# AGENTS.md — Molades v0.5\n",
        "Twelve procedures. Follow the one named. Do not blend them.\n",
        "Standing rules for all twelve:\n",
        "- You draft. The student decides. Draft early and badly rather than late and blank.",
        "- You never invent evidence. No quotes, personas, simulated users, or invented numbers.",
        "- Every decision names what it rejected, and why.",
        "- Show before you ask. Never a question against a blank space.\n",
        "There is one gate, about foundations only: real data before synthesis, an object",
        "model before building. Everything else is a flag with a forward path, never a stop.\n",
        "Every procedure ends by writing to `LOG.md` — or handing back a paste-ready block",
        "if this tool cannot write files.\n",
        "| Procedure | Run when | Produces |",
        "|---|---|---|",
        "| molades-start | Lost, or starting | A route to one next command |",
        "| molades-scope | An idea, no bet | `SCOPE.md` |",
        "| molades-landscape | A bet, no competitor work | Landscape section in `SCOPE.md` |",
        "| molades-research | Before or after collecting | `RESEARCH.md` |",
        "| molades-synthesise | Data collected | Clusters, jobs, problem statement |",
        "| molades-define | A problem statement | `DESIGN.md` — screens, main path, states |",
        "| molades-language | Structure done, references in hand | `LANGUAGE.md` + component sheet |",
        "| molades-build | The plan is written down | A deployed URL |",
        "| molades-stress | A build that works on perfect data | Stress table + rewritten States |",
        "| molades-craft | A build that looks amateur | PASS/FAIL/CAN'T TELL table + 5 fixes |",
        "| molades-challenge | Any stage, any time | Findings routed to root layers |",
        "| molades-case | Log is full | `CASE_STUDY.md` |",
        "",
    ]
    for slug, name, desc, body in skills:
        parts.append("\n---\n")
        parts.append(f"# PROCEDURE: {slug}\n")
        parts.append(f"> **Invoke when:** {desc}\n")
        parts.append(body.rstrip())
    return [write(ADAPTERS / "AGENTS.md", "\n".join(parts) + "\n")]


def main():
    skills = load_all()
    made = []
    made += build_cursor(skills)
    made += build_paste(skills)
    made += build_agents(skills)
    print(f"{len(skills)} skills → {len(made)} adapter files")
    for p in made:
        print(f"  {p.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
