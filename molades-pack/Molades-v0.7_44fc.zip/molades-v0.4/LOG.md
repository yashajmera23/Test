# [Your name] — Build Log

**Project:** [one line]
**Started:** [date]

> Copy this file into your project folder. **You don't fill it in — the skills write to it.**
> If you're using a tool that can't write files, each skill hands you a block to paste. Paste it then, not later.
> Newest entry at the bottom, because a log is a story and stories read forward.

---

## Where things stand

*These lines get overwritten in place. Everything below this block only ever gets added to.*

```
Bet:        [the hypothesis in one line]
Evidence:   enough / thin / none
Files:      SCOPE.md [ ] · RESEARCH.md [ ] · DESIGN.md [ ] · LANGUAGE.md [ ] · build [ ] · live [ ]
Rounds:     [count of critique → change, from distinct sources]
Open:       [what's knowingly unfinished]
Next:       /molades-[command]
```

---

## What goes in here

Four entry types. Use the one that's true, not the one that sounds best.

| Type | When |
|---|---|
| `DECISION` | You chose something and rejected something else |
| `CRITIQUE` | Something was found wrong — by you, a model, a peer, a user, or a facilitator |
| `CHANGE` | Something in the work actually changed, and something caused it |
| `LEARNED` | You were wrong about something and found out |

**`LEARNED` entries are the most valuable ones in this file.** A log containing only successes describes a project that never learned anything, and it produces a case study nobody believes. Don't tidy them up later, and don't delete an entry because it now looks naive — the naive entry is the evidence you learned something.

**A decision isn't valid without a rejected alternative.** *"Chose bottom nav"* is a note. *"Chose bottom nav over a drawer because three of five jobs are reached in two taps and the drawer hid all of them behind one"* is a decision. Only the second survives an interview.

In the final session you assemble your case study out of this file and nothing else. If that takes ninety minutes, this worked.

---

## Entries

<!-- newest at the bottom -->

### DECISION · [YYYY-MM-DD] · [skill]
**Decided:**
**Rejected:**
**Because:**
**Confidence:** observed / inferred / assumed

---

### CRITIQUE · [YYYY-MM-DD] · [skill] · Source: self / model / peer / user / facilitator
**Finding:** [what, where, under what condition]
**Severity:** blocker / major / minor
**Root:** the bet / naming / flow / states / looks
**Action:** fixed / deferred / rejected — [and why]

---

### CHANGE · [YYYY-MM-DD] · [skill]
**Changed:**
**Caused by:** [a specific CRITIQUE, by date and source. "General feedback" isn't a cause.]
**Result:**

---

### LEARNED · [YYYY-MM-DD] · [skill]
**Believed:**
**Found:**
**Changed:**
**What this made worthless:** [say it plainly — this line is the one that carries a case study]
