# Setup — one page, find your tool

You need two things working before you start:

1. Your **AI tool**, with the skills loaded
2. **`LOG.md`** copied into your project folder

Find your tool below. Ignore the rest.

---

## What changes between tools

The skills are identical everywhere. What changes is **who does the mechanical work**:

| | Claude Code | Claude Desktop | Cursor | ChatGPT / Gemini web |
|---|---|---|---|---|
| Writes `LOG.md` for you | ✅ | ⛔ hands you blocks | ✅ | ⛔ hands you blocks |
| Writes your files | ✅ | ⛔ you save them | ✅ | ⛔ you save them |
| Runs the design loop unattended | ✅ | ⛔ you screenshot | ⚠️ usually | ⛔ you screenshot |
| Reads your screenshots | ✅ | ✅ | ✅ | ✅ |
| Deploys for you | ✅ | ⛔ | ✅ | ⛔ |

**Nothing is unavailable anywhere.** In the ⛔ cases you do one mechanical step by hand — take a screenshot, save a file, paste a block. The thinking is the same.

**Claude Code is what's demoed in class**, and it's the smoothest by a distance. If you can use it, use it.

---

## Claude Code — recommended

1. Make a folder for your project. Open it in Claude Code.
2. Inside it create `.claude/skills/` and `.claude/commands/`
3. Copy the ten folders from `skills/` into `.claude/skills/`, keeping the folder names.
4. Copy the eleven files from `commands/` into `.claude/commands/`
5. Copy `CORE_RULES.md`, `QUESTION_BANK.md`, `RESEARCH_EXPORT_SPEC.md` and `LOG.md` into the project root.

```
your-project/
  .claude/
    skills/
      molades-start/SKILL.md
      molades-scope/SKILL.md
      ... (ten total)
    commands/
      molades-start.md
      ... (eleven total)
  CORE_RULES.md
  QUESTION_BANK.md
  RESEARCH_EXPORT_SPEC.md
  LOG.md
```

Then say **"let's begin"**, or type `/molades-start`.

**Check it worked:** type `/mol` and the commands should appear. If they don't, the files are in the wrong folder.

---

## Claude Desktop (Projects)

1. Create a Project.
2. Upload your research files to Project knowledge.
3. Paste the contents of one `PASTE.md` from `adapters/paste/` into the chat when you want to run that skill.

**One skill per conversation.** Don't put several into the Project's custom instructions — they bleed into each other and you get a scope card when you asked for a critique.

Your `LOG.md` lives in a Google Doc or a Notion page. Every skill ends by handing you a block. **Paste it immediately.** Later does not happen.

---

## Cursor

1. In your project root, create `.cursor/rules/`
2. Copy the ten `.mdc` files from `adapters/cursor/` into it.
3. They're set to manual invocation — reference them by name: *"Use the molades-scope rule."*

Cursor reads your project files directly, so put your research in the project folder before you start.

---

## Codex / Antigravity / other agentic tools

1. Copy `adapters/AGENTS.md` into your project root.
2. It contains all ten skills, separated by headings.
3. Invoke by name: *"Follow the molades-scope procedure in AGENTS.md."*

Most agentic tools read `AGENTS.md` automatically. If yours doesn't, paste the relevant section into chat.

---

## ChatGPT web / Gemini web / anything with no filesystem

1. Open `adapters/paste/`, pick the skill you want.
2. Paste the whole block into a **fresh conversation**. Not a continuing one.
3. Attach or paste your research.

**Two things that will bite you:**

- **Fresh conversation per skill.** These are long instructions. Running a synthesis in the same thread as a research check means the check's conclusions leak in as assumptions.
- **You maintain the files.** When a skill hands you a block, paste it into your log immediately.

For `/molades-language`, you'll be the camera: the skill writes the test screen, you open it and screenshot it, you paste the screenshot back, it scores and corrects. Five rounds, maybe twenty minutes. Same result.

---

## Everyone — the log

One file. `LOG.md`. Google Doc, Notion page or a markdown file — doesn't matter, as long as it's one place and it's shareable.

Submit the link on day one. It gets spot-checked at the top of every session, and the check is always the same question: **pick a line — where did this come from?**

---

## If something breaks

Bring the actual transcript to the clinic hour. Not a description of what went wrong — the transcript. Nearly every failure here is a setup or framing problem visible in the first two messages, and invisible in a summary.
